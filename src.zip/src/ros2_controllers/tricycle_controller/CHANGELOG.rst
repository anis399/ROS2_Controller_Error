^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package tricycle_controller
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

2.17.0 (2023-02-13)
-------------------

2.16.1 (2023-01-31)
-------------------

2.16.0 (2023-01-19)
-------------------
* Add backward_ros to all controllers (`#489 <https://github.com/ros-controls/ros2_controllers/issues/489>`_) (`#493 <https://github.com/ros-controls/ros2_controllers/issues/493>`_)
* Contributors: Bence Magyar

2.15.0 (2022-12-06)
-------------------
* [TricycleController] Removed “publish period” functionality ⏱ #abi-break #behavior-break (`#468 <https://github.com/ros-controls/ros2_controllers/issues/468>`_)
* Contributors: Robotgir, Denis Štogl

2.14.0 (2022-11-18)
-------------------
* Include <string> to fix compilation error on macOS (`#467 <https://github.com/ros-controls/ros2_controllers/issues/467>`_)
* Contributors: light-tech

2.13.0 (2022-10-05)
-------------------

2.12.0 (2022-09-01)
-------------------
* Fix formatting CI job (`#418 <https://github.com/ros-controls/ros2_controllers/issues/418>`_)
* Fix formatting because pre-commit was not running on CI for some time. (`#409 <https://github.com/ros-controls/ros2_controllers/issues/409>`_)
* Contributors: Denis Štogl, Tyler Weaver

2.11.0 (2022-08-04)
-------------------
* Tricycle controller (`#345 <https://github.com/ros-controls/ros2_controllers/issues/345>`_)
* Contributors: Bence Magyar, Tony Najjar
