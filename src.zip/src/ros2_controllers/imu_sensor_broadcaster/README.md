imu_sensor_broadcaster
==========================================

Controller to publish readings of IMU sensors.

Pluginlib-Library: imu_sensor_broadcaster

Plugin: imu_sensor_broadcaster/IMUSensorBroadcaster (controller_interface::ControllerInterface)
