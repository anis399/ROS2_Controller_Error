Read the `Docs`_ for example usage and command line arguments.

.. _Docs: https://control.ros.org/master/doc/ros2_control/ros2controlcli/doc/userdoc.html
