^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package ros2_control
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

2.22.0 (2023-01-31)
-------------------

2.21.0 (2023-01-24)
-------------------

2.20.0 (2023-01-12)
-------------------

2.19.0 (2023-01-06)
-------------------

2.18.0 (2022-12-03)
-------------------

2.17.0 (2022-11-27)
-------------------

2.16.0 (2022-10-17)
-------------------

2.15.0 (2022-09-19)
-------------------

2.14.0 (2022-09-04)
-------------------

2.13.0 (2022-08-03)
-------------------

2.12.1 (2022-07-14)
-------------------

2.12.0 (2022-07-09)
-------------------
* Move Joint Limits structures for use in controllers (`#462 <https://github.com/ros-controls/ros2_control/issues/462>`_)
* Contributors: Denis Štogl, Andy Zelenak, Bence Magyar

2.11.0 (2022-07-03)
-------------------
* Update maintainers of packages (`#753 <https://github.com/ros-controls/ros2_control/issues/753>`_)
* Contributors: Bence Magyar

2.10.0 (2022-06-18)
-------------------

2.9.0 (2022-05-19)
------------------

2.8.0 (2022-05-13)
------------------

2.7.0 (2022-04-29)
------------------

2.6.0 (2022-04-20)
------------------

2.5.0 (2022-03-25)
------------------

2.4.0 (2022-02-23)
------------------

2.3.0 (2022-02-18)
------------------

2.2.0 (2022-01-24)
------------------
* Use correct ros-controls/realtime_tools branch (`#619 <https://github.com/ros-controls/ros2_control/issues/619>`_)
* No need to get angles from source anymore, causes issues now (`#616 <https://github.com/ros-controls/ros2_control/issues/616>`_)
* Contributors: Bence Magyar, Melvin Wang

2.1.0 (2022-01-11)
------------------

2.0.0 (2021-12-29)
------------------
* Point control_msgs to galactic branch (`#587 <https://github.com/ros-controls/ros2_control/issues/587>`_)
* Contributors: Denis Štogl

1.2.0 (2021-11-05)
------------------

1.1.0 (2021-10-25)
------------------

1.0.0 (2021-09-29)
------------------
* Add missing packages in the metapackage (`#534 <https://github.com/ros-controls/ros2_control/issues/534>`_)
* Contributors: Denis Štogl

0.8.0 (2021-08-28)
------------------

0.7.1 (2021-06-15)
------------------

0.7.0 (2021-06-06)
------------------

0.6.1 (2021-05-31)
------------------

0.6.0 (2021-05-23)
------------------

0.5.0 (2021-05-03)
------------------

0.4.0 (2021-04-07)
------------------

0.3.0 (2021-03-21)
------------------

0.2.1 (2021-03-02)
------------------

0.2.0 (2021-02-26)
------------------

0.1.6 (2021-02-05)
------------------

0.1.5 (2021-02-04)
------------------

0.1.4 (2021-02-03)
------------------
* Add test assets package (`#289 <https://github.com/ros-controls/ros2_control/issues/289>`_)
* Contributors: Denis Štogl

0.1.3 (2021-01-21)
------------------

0.1.2 (2021-01-06)
------------------

0.1.1 (2020-12-23)
------------------
* Remove transmission_interface from release, add ros2cli to ros_control (`#280 <https://github.com/ros-controls/ros2_control/issues/280>`_)
  * Remove transmission_interface from release, add ros2cli to ros_control
  metapackage
  * patch
* Contributors: Bence Magyar

0.1.0 (2020-12-22)
------------------
* Remove controller parameter server (`#113 <https://github.com/ros-controls/ros2_control/issues/113>`_)
* Add ros2_control metapackage
* Contributors: Anas Abou Allaban, Bence Magyar, Karsten Knese, Matt Reynolds
